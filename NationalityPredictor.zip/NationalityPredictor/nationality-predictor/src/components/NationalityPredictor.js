
import React, { useState, useEffect, useRef } from 'react';
import './NationalityPredictor.css';

function NationalityPredictor() {
  // State variables for input, fetched nationality data, error, and loading status.
  const [name, setName] = useState('');
  const [nationality, setNationality] = useState(null);
  const [error, setError] = useState(null);  // Error state
  const [loading, setLoading] = useState(false);  // Loading state

  // useRef for input focus
  const inputRef = useRef();

  // Auto-focus on the input field when component mounts
  useEffect(() => {
    inputRef.current.focus();
  }, []);

  // Function to fetch nationality data from the API
  const fetchNationality = async () => {
    // Clear previous results and errors
    setNationality(null);
    setError(null);

    // Check if the input is empty
    if (!name) {
      setError('Please enter a name.');  // Show error if input is empty
      return;
    }

    try {
      setLoading(true);  // Set loading to true while waiting for the API response
      const response = await fetch(`https://api.nationalize.io?name=${name}`);
      if (!response.ok) {
        throw new Error('Failed to fetch nationality data. Please try again.');
      }
      const data = await response.json();
      setNationality(data);
    } catch (error) {
      setError(error.message);  // Set error message if the API request fails
    } finally {
      setLoading(false);  // Set loading to false after the API call finishes
    }
  };

  return (
    <div className="container mt-5">
      <div className="card shadow p-5 nationality-card">
        <h1 className="text-center mb-4">Predict Nationality</h1>

        {/* Input field and button */}
        <div className="input-group mb-3">
          <input
            ref={inputRef}
            type="text"
            className="form-control"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter a name"
          />
          <button className="btn btn-primary" onClick={fetchNationality}>
            {loading ? 'Loading...' : 'Predict'}  {/* Show loading indicator */}
          </button>
        </div>

        {/* Error message */}
        {error && (
          <div className="alert alert-danger mt-3" role="alert">
            {error}
          </div>
        )}

        {/* Display nationality data if available */}
        {nationality && nationality.country && nationality.country.length > 0 && (
          <div className="mt-4">
            <h2 className="text-center">Nationality Predictions for {name}:</h2>
            <table className="table table-bordered mt-3">
              <thead>
                <tr>
                  <th scope="col">Country</th>
                  <th scope="col">Probability</th>
                </tr>
              </thead>
              <tbody>
                {nationality.country.map((country, index) => (
                  <tr key={index}>
                    <td>{country.country_id}</td>
                    <td>{(country.probability * 100).toFixed(2)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default NationalityPredictor;
