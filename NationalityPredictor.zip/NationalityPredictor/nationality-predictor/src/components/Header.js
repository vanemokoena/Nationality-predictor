import React from 'react';


function Header() {
  return (
    <header className="navbar navbar-expand-lg navbar-light bg-primary text-white">
      <div className="container">
        <h1 className="navbar-brand">Nationality Predictor</h1>
        <p className="navbar-text">
          
        </p>
      </div>
    </header>
  );
}

export default Header;
